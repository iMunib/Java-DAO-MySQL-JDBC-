package TheDataAcessLayer;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * The purpose for this class is to get the information of mySQL platform such
 * as username, password and use it to set up a connection to query the
 * database.
 * Credit: Used Stanley's code as a reference for my project.
 * 
 * @author Rehman
 */
public class DataSourceMySQL {

	/**
	 * setting the {@link Connection} object to null
	 */
	private Connection connection = null;

	/**
	 * This method is called to establish a connection with mySQL using the
	 * database.properties file
	 * 
	 * @return Return the connection if it was not already set.
	 */
	public Connection createConnection() {

		Properties props = new Properties();

		try (InputStream in = Files.newInputStream(Paths.get(
				"C:\\Users\\Munib\\Documents\\NetBeansProjects\\Rehman.Muhammad.Lab2\\src\\rehman\\muhammad\\lab2\\database.properties"));) {
			props.load(in);
		} catch (IOException e) {

			e.printStackTrace();
		}

		String url = props.getProperty("jdbc.url");
		String username = props.getProperty("jdbc.username");
		String password = props.getProperty("jdbc.password");
		try {
			if (connection != null) {
				System.out.println("Cannot create new connection, one exists already");
			} else {
				connection = DriverManager.getConnection(url, username, password);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return connection;
	}
}
