package TheDataAcessLayer;

import TheTransferObject.OntarioDTO;
import java.util.List;

/**
 * This interface will be implemented by {@link OntarioDaoMethods} to connect
 * with the DB and work with {@link OntarioDTO} datatypes
 * Credit: Used Stanley's code as a reference for my project.
 * 
 * @author Rehman
 */
public interface OntarioDao {

	/**
	 * Get All Instances
	 * 
	 * @return All Instances
	 */
	List<OntarioDTO> getAllInstances();

	/**
	 * get Recipient By thier AwardID
	 * 
	 * @param awardID The recipients AwardID
	 * @return The recipient
	 */
	OntarioDTO getRecipientByAwardId(Integer awardID);

	/**
	 * Add a recipient
	 * 
	 * @param instance The recipient
	 */
	void addInstance(OntarioDTO instance);

	/**
	 * update a recipient
	 * 
	 * @param instance The recipient
	 */
	void updateInstance(OntarioDTO instance);

	/**
	 * delete a recipient
	 * 
	 * @param instance The recipient
	 */
	void deleteInstance(OntarioDTO instance);

}
