package rehman.muhammad.lab2;

/**
 *This is the main class to run the application.
 *Credit: Used Stanley's code as a reference for my project.
 * @author Rehman
 */
public class RehmanMuhammadLab2 {

	/**
	 * main
	 * 
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		// TODO code application logic here
		ClassDemo demo = new ClassDemo();
		demo.show();

	}

}
