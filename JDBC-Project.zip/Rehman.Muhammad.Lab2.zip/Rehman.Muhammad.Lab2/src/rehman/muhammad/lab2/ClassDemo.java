package rehman.muhammad.lab2;

import TheBusinessLayer.BusinessLogic;
import TheBusinessLayer.ValidationException;
import TheDataAcessLayer.DataSourceMySQL;
import TheTransferObject.OntarioDTO;
import java.util.List;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Rehman Class implemented to demonstrate the methods of DAO and DTO
 *         objects. IT will apply printing all the recipients, inserting,
 *         printing just one, updating on to the DB and Deleting the last one of
 *         the recipients 
 *         Credit: Used Stanley's code as a reference for my project.
 */
public class ClassDemo {
/**
 * this method will be used for the demo to demonstrate all the methods are working properly from the {@link BusinessLogic} class.
 */
	public void show() {

		try {
			BusinessLogic logic = new BusinessLogic();
			List<OntarioDTO> list = null;
			OntarioDTO recipient = null;

// Printing all the rows            
			System.out.println("Printing recipient");
			list = logic.getAllRecipients();
			printRecipients(list);

			// printing all the rows + our new user
			System.out.println("Inserting One recipient");
			recipient = new OntarioDTO();
			recipient.setName("Munib");
			recipient.setYear(2023);
			recipient.setCity("TCity71");
			recipient.setCategory("TCategory");
			logic.addRecipient(recipient);
			list = logic.getAllRecipients();
			printRecipients(list);

			// printing one recipient
			System.out.println("Printing One recipient");
			recipient = logic.getInstanceByInstanceId(7);
			printRecipient(recipient);
			System.out.println();

			// updating a recipient
			System.out.println("Updating a recipient");
			recipient = new OntarioDTO();
			recipient.setOntarioAwardID(8);
			recipient.setCity("UpdatingCity");
			recipient.setCategory("UpdatingCAT");
			recipient.setName("Hi");
			recipient.setYear(3000);
			logic.updateInstance(recipient);
			list = logic.getAllRecipients();
			printRecipients(list);
			// deleting a recipient
			System.out.println("Deleting last recipient");
			recipient = list.get(list.size() - 1);
			logic.deleteInstance(recipient);
			list = logic.getAllRecipients();
			printRecipients(list);

			System.out.println("Printing the MetaData");
			printMetaData();

		} catch (ValidationException e) {
			System.out.println(e.getMessage());

		}

	}

	/**
	 * This will print out a row of the recipient dataset in a formatted way.
	 * 
	 * @param recipient The recipient to be printed.
	 */
	private void printRecipient(OntarioDTO recipient) {
		String output = String.format("%d, %s, %d, %s, %s", recipient.getOntarioAwardID(), recipient.getName(),
				recipient.getYear(), recipient.getCity(), recipient.getCategory());
		System.out.println(output);
	}

	/**
	 * This will print out a list of recipients using the printRecipient() method in
	 * a formatted way.
	 * 
	 * @param listOfRecipients The list of recipients.
	 */
	private void printRecipients(List<OntarioDTO> listOfRecipients) {
		for (OntarioDTO Recipient : listOfRecipients) {
			printRecipient(Recipient);
		}
		System.out.println();
	}

	/**
	 * This will print out the datasets attributes such as the column name, column
	 * type (the MySQL type) and corresponding Java class for the column
	 */
	private void printMetaData() {
		try {
			PreparedStatement prepStatement = null;
			ResultSet rs = null;
			DataSourceMySQL ds = new DataSourceMySQL();
			Connection con = ds.createConnection();
			prepStatement = con.prepareStatement("SELECT * FROM Recipients");
			rs = prepStatement.executeQuery();
			java.sql.ResultSetMetaData metaData = rs.getMetaData();
			int columnsOfTable = metaData.getColumnCount();
			System.out.println();
			for (int i = 1; i <= columnsOfTable; i++) {
				System.out.printf("%-8s\t", metaData.getColumnName(i));
				System.out.printf("%-8s\t", metaData.getColumnTypeName(i));
				System.out.printf("%-8s\t", metaData.getColumnClassName(i));
				System.out.printf("\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
