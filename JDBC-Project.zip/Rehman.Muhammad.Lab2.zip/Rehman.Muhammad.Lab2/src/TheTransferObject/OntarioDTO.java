
package TheTransferObject;

import TheBusinessLayer.BusinessLogic;
import TheDataAcessLayer.OntarioDaoMethods;
import rehman.muhammad.lab2.ClassDemo;

/**
 * This class is the DTO that have the variables to set and get for the
 * recipients we will using in {@link BusinessLogic}, {@link OntarioDaoMethods},
 * {@link ClassDemo}. Credit: Used Stanley's code as a reference for my project.
 * 
 * @author Rehman
 * 
 */
public class OntarioDTO {
	/**
	 * The AwardID
	 */
	private Integer ontarioID;
	/**
	 * The name
	 */
	private String name;
	/**
	 * The year
	 */
	private Integer year;
	/**
	 * The city
	 */
	private String city;
	/**
	 * The category
	 */
	private String category;

	/**
	 * This will retrieve The AwardID
	 * 
	 * @return The AwardID
	 */
	public Integer getOntarioAwardID() {
		return ontarioID;
	}

	/**
	 * set OntarioAwardID
	 * 
	 * @param ontarioID value of ontarioId
	 */
	public void setOntarioAwardID(Integer ontarioID) {
		this.ontarioID = ontarioID;
	}

	/**
	 * This will retrieve The AwardID
	 * 
	 * @return The name
	 */
	public String getName() {
		return name;
	}

	/**
	 * set Name
	 * 
	 * @param name value of Name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * This will retrieve The year
	 * 
	 * @return The year
	 */
	public Integer getYear() {
		return year;
	}

	/**
	 * set Year
	 * 
	 * @param year value of Year
	 */
	public void setYear(Integer year) {
		this.year = year;
	}

	/**
	 * This will retrieve The city
	 * 
	 * @return The city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * set City
	 * 
	 * @param city value of City
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * This will retrieve The category
	 * 
	 * @return The category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * set Category
	 * 
	 * @param category value of Category
	 */
	public void setCategory(String category) {
		this.category = category;
	}

}
