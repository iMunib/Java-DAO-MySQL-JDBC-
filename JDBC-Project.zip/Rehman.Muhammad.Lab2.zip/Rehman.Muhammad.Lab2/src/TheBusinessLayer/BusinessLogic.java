package TheBusinessLayer;

import TheDataAcessLayer.OntarioDao;
import TheDataAcessLayer.OntarioDaoMethods;
import TheTransferObject.OntarioDTO;
import java.util.List;

/**
 * This class is the business logic that will call the {@link OntarioDaoMethods}
 * within its method call to do the operation. This will be the class that the
 * outside communicates with and this will communicate with the DAO. This class
 * also has methods to validate and clean the data to make sure its appropriate
 * to add to the DB.
 * Credit: Used Stanley's code as a reference for my project.
 * 
 * @author Rehman
 */
public class BusinessLogic {
	/**
	 * the max length a cell value can have
	 */
	private static final int MAX_LENGTH = 50;
	/**
	 * an object of {@link OntarioDao} interface.
	 */
	private OntarioDao ontarioDao = null;

	/**
	 * default constructor that makes an object to {@link OntarioDaoMethods}
	 */
	public BusinessLogic() {
		ontarioDao = new OntarioDaoMethods();
	}

	/**
	 * Uses the {@link OntarioDaoMethods} object to call the getAllInstances method
	 * to return all the instances in the table.
	 * 
	 * @return All the Instances
	 */
	public List<OntarioDTO> getAllRecipients() {
		return ontarioDao.getAllInstances();
	}

	/**
	 * Uses the {@link OntarioDaoMethods} object to call the addInstance method to
	 * add a recipient
	 * 
	 * @param recipient add the Recipient
	 * @throws ValidationException Data cleaning/Validation
	 */
	public void addRecipient(OntarioDTO recipient) throws ValidationException {
		cleanRecipient(recipient);
		validateRecipient(recipient);
		ontarioDao.addInstance(recipient);
	}

	/**
	 * Uses the {@link OntarioDaoMethods} object to call the getInstanceByInstanceId
	 * method to show a recipient by their AwardID
	 * 
	 * @param awardID AwardID value
	 * @return The recipient
	 * @throws ValidationException Data cleaning/Validation
	 */
	public OntarioDTO getInstanceByInstanceId(Integer awardID) throws ValidationException {
		return ontarioDao.getRecipientByAwardId(awardID);

	}

	/**
	 * Uses the {@link OntarioDaoMethods} object to call the updateInstance method
	 * to update a recipient
	 * 
	 * @param instance the Recipient
	 * @throws ValidationException Data cleaning/Validation
	 */
	public void updateInstance(OntarioDTO instance) throws ValidationException {
		cleanRecipient(instance);
		validateRecipient(instance);
		ontarioDao.updateInstance(instance);
	}

	/**
	 * Uses the {@link OntarioDaoMethods} object to call the deleteInstance method
	 * to delete a recipient
	 * 
	 * @param instance the Recipient
	 * @throws ValidationException Data cleaning/Validation
	 */
	public void deleteInstance(OntarioDTO instance) throws ValidationException {
		cleanRecipient(instance);
		validateRecipient(instance);
		ontarioDao.deleteInstance(instance);
	}

	/**
	 * This method cleans the data, making sure the values aren't null and trim the
	 * values and then setting the values
	 * 
	 * @param recipientPassed the Recipient
	 */
	private void cleanRecipient(OntarioDTO recipientPassed) {
		if (recipientPassed.getName() != null) {
			recipientPassed.setName(recipientPassed.getName().trim());
		}
		if (recipientPassed.getCategory() != null) {
			recipientPassed.setCategory(recipientPassed.getCategory().trim());
		}
		if (recipientPassed.getCity() != null) {
			recipientPassed.setCity(recipientPassed.getCity().trim());
		}
		if (recipientPassed.getYear() != null) {
			recipientPassed.setYear(recipientPassed.getYear());
		}
	}

	/**
	 * Validate the data such as max length, is not null, empty or too long.
	 * 
	 * @param recipient the Recipient
	 * @throws ValidationException Data cleaning/Validation
	 */
	private void validateRecipient(OntarioDTO recipient) throws ValidationException {
		validateString(recipient.getCategory(), "Category", MAX_LENGTH, true);
		validateString(recipient.getCity(), "City", MAX_LENGTH, true);
		validateString(recipient.getName(), "Name", MAX_LENGTH, true);
		validateInt(recipient.getYear(), "Year");
	}

	/**
	 * 
	 * @param value         String value
	 * @param fieldName     The field
	 * @param maxLength     The max char
	 * @param isNullAllowed Yes or no if its not null
	 * @throws ValidationException Data cleaning/Validation
	 */
	private void validateString(String value, String fieldName, int maxLength, boolean isNullAllowed)
			throws ValidationException {
		if (value == null && isNullAllowed) {
			// return; // null permitted, nothing to validate
		} else if (value == null && !isNullAllowed) {
			throw new ValidationException(String.format("%s cannot be null", fieldName));
		} else if (value.length() == 0) {
			throw new ValidationException(String.format("%s cannot be empty or only whitespace", fieldName));
		} else if (value.length() > maxLength) {
			throw new ValidationException(String.format("%s cannot exceed %d characters", fieldName, maxLength));
		}
	}

	/**
	 * 
	 * @param value     The value
	 * @param fieldName The field
	 * @throws ValidationException Data cleaning/Validation
	 */
	private void validateInt(int value, String fieldName) throws ValidationException {
		if (value <= 0) {
			throw new ValidationException(String.format("%s cannot be a negative number", fieldName));
		}
	}

}
