package TheBusinessLayer;

/**
 * This class is for custom exception handling for the methods used in
 * {@link BusinessLogic}.
 * Credit: Used Stanley's code as a reference for my project.
 * 
 * @author Rehman
 */
public class ValidationException extends Exception {

	/**
	 * Throw a custom exception
	 */
	public ValidationException() {
		super("Data not in valid format");
	}

	/**
	 * Throw a custom exception
	 * @param message String message
	 */
	public ValidationException(String message) {
		super(message);
	}

	/**
	 * Throw a custom exception
	 * @param message String message
	 * @param throwable Throwable throwable
	 */
	public ValidationException(String message, Throwable throwable) {
		super(message, throwable);
	}

	/**
	 * Throw a custom exception
	 * @param throwable Throwable
	 */
	public ValidationException(Throwable throwable) {
		super(throwable);
	}
}
